#include "libA/sourceA.h"
#include "privateHeaderA1.h"
#include "privateHeaderA2.h"

#include <iostream>

void printA()
{
	printA1();
	printA2();
	std::cout << "This is libA\n";
	printB();
}