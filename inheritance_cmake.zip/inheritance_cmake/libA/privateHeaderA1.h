#ifndef A1
#define A1

#include <iostream>

void printA1()
{
	std::cout << "A1\n";
}

#endif