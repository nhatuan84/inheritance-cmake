#ifndef LIBA
#define LIBA

#include "libB/sourceB.h"

void printA();

#endif
