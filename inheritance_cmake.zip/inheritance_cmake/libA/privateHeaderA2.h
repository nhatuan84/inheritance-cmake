#ifndef A2
#define A2

#include <iostream>

void printA2()
{
	std::cout << "A2\n";
}

#endif