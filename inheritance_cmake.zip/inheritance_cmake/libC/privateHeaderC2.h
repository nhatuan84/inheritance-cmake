#ifndef C2
#define C2

void printC2();

#endif