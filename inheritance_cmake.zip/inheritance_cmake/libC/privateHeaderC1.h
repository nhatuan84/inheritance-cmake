#ifndef C1
#define C1

#include <iostream>

void printC1();

#endif