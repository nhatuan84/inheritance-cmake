#ifndef LIBC
#define LIBC

void printC();

#endif
