#include "libC/sourceC.h"
#include "privateHeaderC1.h"
#include "privateHeaderC2.h"

#include <iostream>

void printC1()
{
	std::cout << "C1\n";
}

void printC2()
{
	std::cout << "C2\n";
}

void printC()
{
	printC1();
	printC2();
	std::cout << "This is libC\n";
}