#ifndef B1
#define B1

void printB1();

#endif