#include "libC/sourceC.h"
#include "libB/sourceB.h"
#include "submodule.h"
#include "privateHeaderB1.h"
#include "privateHeaderB2.h"

#include <iostream>

void printB1()
{
	std::cout << "B1\n";
}

void printB2()
{
	std::cout << "B2\n";
}

void printB()
{
	printB1();
	printB2();
	std::cout << "This is libB\n";
	printSubModule();
	printC();
}