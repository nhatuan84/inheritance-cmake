#ifndef B2
#define B2

void printB2();

#endif