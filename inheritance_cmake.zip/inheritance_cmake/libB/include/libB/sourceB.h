#ifndef LIBB
#define LIBB

void printB();

#endif
