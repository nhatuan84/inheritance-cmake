#include "submodule.h"
#include <iostream>

void printSubModule()
{
	std::cout << "B SubModule\n";
}

