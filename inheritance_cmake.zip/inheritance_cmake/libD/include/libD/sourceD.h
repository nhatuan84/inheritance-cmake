#ifndef LIBD
#define LIBD

#include <iostream>

void printD()
{
#if defined(D1)
	std::cout << "D1\n";
#elif defined(D2)
	std::cout << "D2\n";
#endif
}

#endif
