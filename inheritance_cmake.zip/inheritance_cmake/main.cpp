#include "libA/sourceA.h"
#include "libC/sourceC.h"
#include "libB/privateHeaderB1.h"
//#include "libB/submodule.h" //error => because PRIVATE libB/submodule 
//					   //no error PUBLIC libB/submodule 
#include "libD/sourceD.h"

int main()
{
	printA();
	printC();
	printD();
	//printSubModule();
	printB1();
	return 0;
}