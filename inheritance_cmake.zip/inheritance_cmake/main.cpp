#include "libA/sourceA.h"
#include "libC/sourceC.h"
//#include "submodule.h" //error => because PRIVATE libB/submodule 
//					   //no error PUBLIC libB/submodule 
#include "libD/sourceD.h"

int main()
{
	printA();
	printC();
	printD();
	return 0;
}